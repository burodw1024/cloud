# LoanDueReportProcessor 1.1.0 — same processor, endpoint and MCP tool

Target: **Apache NiFi 2.4.0 / Java 21**. This extends the supplied 1.0.0 source.
The class remains `org.scott.nifi.loandue.LoanDueReportProcessor`.

Keep the existing flow:

```
HandleHttpRequest -> LoanDueReportProcessor -> HandleHttpResponse
```

Keep the endpoint **POST http://192.168.1.139:8001/api/loan-due-report** and the
existing MCP registration **loan-due-report**. Do not create another tool or URL.
No new Oracle procedure is required. The existing procedure call is unchanged;
if its output has no unique loan identity, it must expose that existing identity.

## Oracle call verified from the supplied source

The existing call remains `{call SCOTT.GET_LOAN_DUE_REPORT(?, ?, ?)}`:

1. OUT cursor, registered using OracleTypes.CURSOR.
2. IN report date, bound with setDate.
3. IN optional branch code, bound with setString or SQL NULL for all branches.

The processor exhausts the cursor. For ranking it calls the existing procedure
once with a NULL branch, filters the configured zone and authorization scope,
combines ALL selected loans per branch/member, then sorts and limits. No generated
SQL, new procedure, model arithmetic or first-100-row preview is involved.
This may scan the full report and can still hit the existing Oracle timeout.

## Compatibility and fixes

- Missing operation / operation=report preserves the JSON-array report, optional
  branch and configured default report date. Ordinary numeric/date serialization
  is preserved. Existing JDBC/password/default-date/query-timeout property names
  are preserved; the password remains sensitive.
- `operation=rank_overdue_members` requires an explicit date and exactly one zone
  code/name. Top count defaults to 10, maximum 100. It returns the ranking envelope
  already accepted by the deployed Django code. IDs retain leading zeros. Money
  is calculated with BigDecimal and emitted as exact decimal strings.
- Ranking emits only rank, zone, branch, member ID, overdue amount, principal and
  maximum overdue days. Member names, phones and raw loan identity are excluded.
  Zero-due members are excluded after combining loans; principal includes all
  that member's selected loans, including loans with zero current due.
- Ties use branch code then member ID in string order. A member at two branches
  has a separate branch/member aggregate. This is not branch ranking, per-branch
  top-N, risk scoring or a conclusion of misconduct.
- Error responses now transfer the most recent FlowFile, preserving the original
  http.context.identifier for HandleHttpResponse. The original default-date
  expression evaluation used the wrong scope; environment-only evaluation is fixed.
- Duplicate JSON fields/trailing JSON, unknown parameters, numeric identifiers,
  missing source fields, duplicate loans, wrong types, negative/invalid money,
  conflicting branch names/currencies and incomplete/safety-limited results fail
  closed. No automatic database retry is sent. Error bodies exclude SQL internals.

## Build and validation

The upgrade bundle includes the ready-built NAR and a separate source ZIP. Put
only the NAR in NiFi's configured extension location, not either ZIP. To rebuild,
extract the source ZIP, enter its `nifi-loan-due-report` directory, install JDK 21
and Maven 3.9+, then:

```bash
mvn -B clean verify
```

Output: `nar/target/loan-due-report-nar-1.1.0.nar`.

The build tests the real NiFi processor session behavior using nifi-mock and
mocked JDBC objects; it does not contact a production Oracle server. Tests verify
bindings, legacy requests, exact multi-loan totals, full-source top-N, tie order,
access filters, duplicate/invalid data, cursor/response limits, context retention,
HTTP status codes and one-attempt timeout handling.

The processor test also emits `processor/target/contract-ranking-response.json`.
In the cloud Django checkout this was parsed by the actual Django ranking
presenter to verify wire compatibility. Unit/mock validation is not a live
Oracle/NiFi/ContextForge/browser deployment test.

## Required ranking configuration — never infer these business facts

Ranking is **disabled by default**. Existing ordinary reports can continue while
these new properties are configured. Only enable after the following are verified:

| Property | Required value / meaning |
|---|---|
| Ranking zone catalog | JSON object of actual zone-code -> exact ZONENAME mappings. Names must be unique because the cursor does not guarantee a ZONECODE column. Do not invent zone codes. |
| Ranking authorized branches | JSON array of actual branch-code strings authorized for EVERY reader of this fixed-scope endpoint; preserve zeros. Use an empty array only with explicit full-scope approval below. |
| Ranking full report scope approved | False by default. Set true ONLY if every current tool reader is already authorized for the full existing report scope. Mutually exclusive with an explicit branch list. |
| Ranking loan key columns | Comma-separated cursor labels forming a DBA-verified unique loan key. No default identity is assumed. A real loan ID or proven composite of existing fields may be used. Duplicate keys fail the request. |
| Ranking currency | Actual single currency, three uppercase letters. No default currency is invented. |
| Ranking enabled | Set true only after the configuration above is valid. |

The cursor has MEMBERID, PRODUCTNAME, DISBURSEDATE and LOANCYCLE, but their presence
does NOT prove that any particular combination uniquely identifies a loan. If no
combination is unique, the existing procedure must expose its actual loan ID;
that is an additional output field, not another MCP tool or procedure.

The access policy is a fixed service scope shared by every reader of this tool,
not per-employee authorization. Keep the endpoint reachable only through the
existing approved service boundary, and keep the same tool permissions. If users
have different branch entitlements, leave ranking disabled until authenticated
identity-aware scope is enforced upstream or a suitably restricted service scope
is assigned. Request-body fields never authorize access. No permission is granted
automatically by this package.

## Bounds and timeout settings

New defaults: Oracle connect timeout 10s; read timeout 240s (must exceed query
timeout); maximum scanned cursor rows 250000; maximum serialized response 10 MB.
Existing query timeout remains 180s and maximum request size remains 64 KB.
These are safety bounds, not preview limits: reaching one returns an error, not
scopeComplete=true with partial data. The ranking result remains top 1–100 rows.
The Django MCP response-size bound still applies independently.

Preserve the same StandardHttpContextMap on HandleHttpRequest/HandleHttpResponse.
Ensure its expiration and flow queue/scheduling budget cover the configured
operation duration; the existing downstream settings are MCP 300/600s, Gunicorn
660s and Nginx 670s. ContextForge's actual REST-client retry/read behavior must
also be verified separately. This package does NOT resolve Oracle query tuning,
SQLTimeoutException/ORA-01013, stale HTTP contexts, or network disconnects by itself.

## Install with a rollback path

1. Confirm the installed NiFi version is compatible with 2.4.0 and Java 21.
   Preserve the existing flow, Parameter Contexts, controller services, sensitive
   configuration and old NAR. Do not print/export passwords into source control.
2. Stop accepting new requests to this endpoint and drain its in-flight flow.
   Use your NiFi maintenance procedure to load the new NAR from its configured
   extension directory. No installation path or service name is guessed here.
3. Select bundle `org.scott.nifi:loan-due-report-nar:1.1.0` for the SAME processor
   class using NiFi's supported component-version update. If the UI does not
   support that update, create a replacement instance from the 1.1.0 bundle,
   preserve/copy the existing properties via its Parameter Context and reconnect
   the same request/response flow. Keep the original stopped instance for rollback.
   Merely copying the new NAR does not change a flow still referencing 1.0.0.
4. Keep JDBC credentials, endpoint port/path, response relationship and HTTP
   Context Map unchanged. HandleHttpResponse must use `${http.status.code}`.
   Leave ranking disabled initially and verify a known branch/date ordinary report.
5. Configure and validate the ranking properties, then enable ranking and compare
   a small authorized zone against independent Oracle totals. Test zero rows,
   multiple loans, duplicate-key rejection, a disallowed branch and a top member
   outside the first 100 source rows. Keep the old bundle until acceptance passes.
6. Edit the EXISTING ContextForge loan-due-report registration's input schema
   using `mcp-input-schema.json`. Keep its tool ID, URL, POST method, token/auth,
   server scope and visibility/roles unchanged. Do not create a new registration.
   Its description should explain operation=report versus rank_overdue_members.

Example direct requests (run only after real configuration is complete):

```bash
curl --fail-with-body --silent --show-error \
  -H 'Content-Type: application/json' \
  --data '{"branchCode":"0253","reportDate":"2026-09-30"}' \
  http://192.168.1.139:8001/api/loan-due-report
```

```bash
curl --fail-with-body --silent --show-error \
  -H 'Content-Type: application/json' \
  --data '{"operation":"rank_overdue_members","zoneName":"Dhaka","reportDate":"2026-09-30","limit":10}' \
  http://192.168.1.139:8001/api/loan-due-report
```

The second example succeeds only if Dhaka is an actual uniquely mapped zone and
its report scope is approved. No sample catalog or branch grants are enabled in
the package. A successful HTTP response alone does not establish financial
correctness: reconcile the exact member totals/count against Oracle, then test
through the existing MCP tool and Django UI before claiming live success.
